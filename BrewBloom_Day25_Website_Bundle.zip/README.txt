BREWBLOOM CAFÉ | DAY 25 WEBSITE BUNDLE

Included:
- index.html — Home page and sample menu
- about.html — About the café page
- style.css — Shared responsive design

Preview:
Open index.html in a web browser. Keep all three files in the same folder.

Publish free using GitHub Pages:
1. Sign in or create a free account at https://github.com
2. Create a public repository named brewbloom-cafe-site.
3. Upload index.html, about.html and style.css to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select the main branch and /(root), then Save.
7. Wait for GitHub Pages to publish and provide the public URL.

IMPORTANT:
This is a mock café project. Menu items and prices are illustrative. Add the real café address,
phone number, email, opening hours, actual menu and photos before publishing. This bundle
has not yet been uploaded to a hosting account, so no live URL exists yet.
